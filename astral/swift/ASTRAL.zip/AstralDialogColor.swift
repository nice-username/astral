//
//  AstralDialogColor.swift
//  astral
//
//  Created by Joseph Haygood on 5/13/23.
//

import Foundation

enum AstralDialogColor {
    case red
    case green
    case blue
    case white
}
